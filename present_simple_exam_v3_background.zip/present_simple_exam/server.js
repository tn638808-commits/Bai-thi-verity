const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const crypto = require('crypto');
const QUESTIONS = require('./questions');
const app = express(); const server = http.createServer(app);
const io = new Server(server);
const rooms = new Map();
const PORT = Number(process.env.PORT || 3000);
app.use(express.static('public'));
app.put('/api/background', express.json({limit:'5mb'}), (req,res)=>{
 const {room,token,image,fit,overlay}=req.body||{};
 const r=rooms.get(String(room||'').toUpperCase());
 if(!r||!token||token!==r.teacherToken)return res.status(403).json({error:'Không xác thực được giáo viên/phòng.'});
 if(image!==null && image!==undefined && !/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(image))return res.status(400).json({error:'Ảnh không hợp lệ. Hãy chọn PNG, JPG, WEBP hoặc GIF.'});
 r.background=image?{image,fit:['cover','contain','center'].includes(fit)?fit:'cover',overlay:Math.max(0,Math.min(85,Number(overlay)||0))}:null;
 io.to(r.code).emit('room:background',r.background); res.json({ok:true});
});
app.get('/health', (_req,res)=>res.json({ok:true,rooms:rooms.size}));
const publicQs = QUESTIONS.map(({id,level,type,q,opts})=>({id,level,type,q,opts}));
function code(){return Math.random().toString(36).slice(2,8).toUpperCase();}
function clean(s,max=50){return String(s||'').trim().replace(/[<>]/g,'').slice(0,max);}
function roomFor(socket){const r=rooms.get(socket.data.room);return r;}
function isTeacher(socket,r){return !!r && socket.data.role==='teacher' && socket.data.teacherToken===r.teacherToken;}
function studentList(r){return [...r.students.values()].map(s=>({id:s.id,name:s.name,joined:s.joined,submitted:s.submitted,score:s.score,progress:s.progress,alerts:s.alerts.slice(-10),lastSeen:s.lastSeen}));}
function emitRoster(r){if(r.teacherSocket)io.to(r.teacherSocket).emit('teacher:roster',studentList(r));}
function finishExam(r,reason='Đã kết thúc bài thi'){
 if(!r.started || r.ended) return; r.ended=true; r.endReason=reason;
 for(const s of r.students.values()) if(!s.submitted){s.submitted=true;s.score=scoreAnswers(s.answers);}
 if(r.timer)clearTimeout(r.timer); io.to(r.code).emit('exam:ended',{reason}); emitRoster(r);
}
function normalize(v){return String(v||'').toLowerCase().trim().replace(/[’']/g,"'").replace(/[.!?]/g,'').replace(/\s+/g,' ');}
function scoreAnswers(ans){let score=0; for(const q of QUESTIONS){let v=ans?.[q.id]; if(q.type==='fill'){const accepted=[q.answer,...(q.alts||[])].map(normalize); if(accepted.includes(normalize(v)))score++;} else if(Number(v)===q.answer)score++;}return score;}
io.on('connection',socket=>{
 socket.on('teacher:create',({duration}={})=>{
   let c; do{c=code();}while(rooms.has(c));
   const r={code:c,teacherToken:crypto.randomBytes(24).toString('hex'),teacherSocket:socket.id,students:new Map(),started:false,ended:false,duration:Math.min(120,Math.max(5,Number(duration)||20)),startedAt:null,endsAt:null,background:null};
   rooms.set(c,r);socket.data.role='teacher';socket.data.room=c;socket.data.teacherToken=r.teacherToken;socket.join(c);
   socket.emit('teacher:created',{code:c,token:r.teacherToken,duration:r.duration,questionCount:QUESTIONS.length});
 });
 socket.on('teacher:reconnect',({code,token}={})=>{const r=rooms.get(String(code||'').toUpperCase());if(!r||!token||token!==r.teacherToken)return socket.emit('teacher:error','Mã phòng hoặc khóa giáo viên không đúng.');socket.data.role='teacher';socket.data.room=r.code;socket.data.teacherToken=r.teacherToken;socket.join(r.code);r.teacherSocket=socket.id;socket.emit('teacher:state',{code:r.code,started:r.started,ended:r.ended,duration:r.duration,endsAt:r.endsAt,roster:studentList(r),background:r.background});});
 socket.on('teacher:start',()=>{const r=roomFor(socket);if(!isTeacher(socket,r)||r.started||r.ended)return;r.started=true;r.startedAt=Date.now();r.endsAt=r.startedAt+r.duration*60*1000;io.to(r.code).emit('exam:start',{duration:r.duration,endsAt:r.endsAt,questions:publicQs});emitRoster(r);r.timer=setTimeout(()=>finishExam(r,'Hết thời gian'),r.duration*60*1000);});
 socket.on('teacher:stop',()=>{const r=roomFor(socket);if(isTeacher(socket,r))finishExam(r,'Giáo viên kết thúc bài thi');});
 socket.on('teacher:kick',studentId=>{const r=roomFor(socket);if(!isTeacher(socket,r))return;const s=r.students.get(studentId);if(s&&!s.submitted){s.submitted=true;s.score=scoreAnswers(s.answers);s.kicked=true;io.to(s.id).emit('student:kicked','Giáo viên đã kết thúc lượt làm bài của bạn.');r.students.delete(studentId);emitRoster(r);}});
 socket.on('student:join',({name,code:roomCode}={})=>{
  const r=rooms.get(String(roomCode||'').toUpperCase());const n=clean(name,40);
  if(!r||!n)return socket.emit('student:error','Mã phòng không đúng hoặc bạn chưa nhập tên.');
  if(r.ended)return socket.emit('student:error','Phòng thi đã kết thúc.');
  if(r.students.size>=100)return socket.emit('student:error','Phòng đã đủ số lượng học sinh.');
  socket.data.role='student';socket.data.room=r.code;socket.data.studentName=n;socket.join(r.code);
  const s={id:socket.id,name:n,joined:Date.now(),submitted:false,score:null,progress:0,alerts:[],answers:{},lastSeen:Date.now()};r.students.set(socket.id,s);
  socket.emit('student:joined',{code:r.code,started:r.started,endsAt:r.endsAt,duration:r.duration,background:r.background,questions:r.started&&!r.ended?publicQs:null});emitRoster(r);io.to(r.code).emit('teacher:notice',{kind:'joined',name:n,message:`${n} tham gia phòng.`});
 });
 socket.on('student:progress',p=>{const r=roomFor(socket);if(!r||socket.data.role!=='student')return;const s=r.students.get(socket.id);if(!s||s.submitted)return;s.progress=Math.max(0,Math.min(100,Number(p)||0));s.lastSeen=Date.now();emitRoster(r);});
 socket.on('student:alert',kind=>{const r=roomFor(socket);if(!r||socket.data.role!=='student')return;const s=r.students.get(socket.id);if(!s||s.submitted||!r.started)return;const allowed=['tab_hidden','window_blur'];if(!allowed.includes(kind))return;const item={kind,time:Date.now(),message:kind==='tab_hidden'?'Chuyển khỏi tab bài thi':'Cửa sổ bài thi mất tiêu điểm'};s.alerts.push(item);io.to(r.code).emit('teacher:notice',{kind:'alert',name:s.name,message:item.message,time:item.time});emitRoster(r);});
 socket.on('student:submit',answers=>{const r=roomFor(socket);if(!r||socket.data.role!=='student'||!r.started||r.ended)return;const s=r.students.get(socket.id);if(!s||s.submitted)return;if(Date.now()>r.endsAt)return finishExam(r,'Hết thời gian');s.answers=answers&&typeof answers==='object'?answers:{};s.submitted=true;s.score=scoreAnswers(s.answers);s.progress=100;socket.emit('student:result',{score:s.score,total:QUESTIONS.length});io.to(r.code).emit('teacher:notice',{kind:'submitted',name:s.name,message:`${s.name} đã nộp bài.`});emitRoster(r);});
 socket.on('disconnect',()=>{const r=roomFor(socket);if(!r)return;if(socket.data.role==='student'){const s=r.students.get(socket.id);if(s&&!s.submitted){s.lastSeen=Date.now();s.alerts.push({kind:'disconnect',time:Date.now(),message:'Mất kết nối'});io.to(r.code).emit('teacher:notice',{kind:'alert',name:s.name,message:'Mất kết nối'});emitRoster(r);}}});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Exam server listening on http://localhost:${PORT}`));
