# Present Simple Exam Room (v2)

## Cách chạy trên máy
1. Cài Node.js (LTS) nếu máy chưa có.
2. Mở thư mục `present_simple_exam` bằng terminal/command prompt.
3. Chạy `npm install` một lần.
4. Chạy `npm start`.
5. Mở `http://localhost:3000`.

## Dùng trong lớp
- Giáo viên mở `/teacher.html`, chọn thời gian và bấm **Tạo phòng mới**. Mã phòng và khóa giáo viên được lưu trong trình duyệt giáo viên để reconnect.
- Gửi mã phòng cho học sinh. Học sinh mở `/student.html`, nhập tên + mã phòng.
- Giáo viên bấm **Bắt đầu bài**. Học sinh làm và nộp; hết giờ hệ thống kết thúc bài.
- Giáo viên theo dõi tiến độ, số lượt nộp, cảnh báo tab/focus; xuất CSV.

## Đưa lên mạng để cả lớp truy cập
Chạy ứng dụng trên máy chủ/hosting có Node.js và HTTPS, giữ cổng web được hosting cấp. Không dùng localhost làm link gửi học sinh vì localhost là máy riêng của từng người.

## Lưu ý về giám sát
- Cảnh báo chuyển tab hoặc mất focus là dấu hiệu tham khảo, không phải bằng chứng chắc chắn học sinh gian lận.
- Trình duyệt web không có cách đáng tin cậy để phát hiện chụp màn hình trên mọi thiết bị.
- Dữ liệu phòng được lưu trong RAM; khởi động lại server sẽ mất phòng và tiến độ. Bản này dành cho thử nghiệm/lớp học nhỏ, chưa có tài khoản, database, TLS tự cấu hình, hay xác thực học sinh.
- Mã giáo viên là bí mật; đừng chia sẻ cho học sinh. Kết quả chấm được tính phía server.

## Ảnh nền phòng thi
Trong bảng giáo viên, sau khi tạo/kết nối phòng, tìm mục Tùy chỉnh ảnh nền phòng thi. Chọn PNG/JPG/WEBP/GIF (tối đa 3.5 MB), chọn cách hiển thị và độ phủ, bấm Áp dụng ảnh nền. Ảnh được chia sẻ tới học sinh trong phòng; bấm Xóa ảnh nền để quay lại nền mặc định.
